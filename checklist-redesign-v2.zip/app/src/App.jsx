import React, { useState, useMemo, useCallback, useEffect } from "react";
import { checklists } from "./Checklists";
import { useRealtimeChecklist } from "./hooks/useRealtimeChecklist";
import { useAuth } from "./hooks/useAuth";
import { useDashboardConfig } from "./hooks/useDashboardConfig";
import { useIsMobile } from "./hooks/useIsMobile";
import ReceptionPanels from "./components/reception/ReceptionPanels";
import MobileBottomNav from "./components/reception/MobileBottomNav";
import { validateUserInput } from "./utils/security";
import { 
  saveHandoverNotes as saveHandoverNotesToDB,
  getHandoverNotes,
  deleteHandoverNotes as deleteHandoverNotesFromDB,
  subscribeToHandoverNotes,
  saveWakeUpCalls,
  subscribeToWakeUpCalls,
  saveBreakfastTimes as saveBreakfastTimesToDB,
  getBreakfastTimes,
  subscribeToBreakfastTimes,
  subscribeToPricingInfo,
  DEFAULT_PRICING,
} from "./firebase/database";
import { signOutUser } from "./firebase/auth";
import { isAdminEmail } from "./config/admin";
import AuthLoginForm from "./components/AuthLoginForm";
import HskLoginForm from "./components/hsk/HskLoginForm";
import HskDashboard from "./components/hsk/HskDashboard";
import FloatingHskWidget from "./components/hsk/FloatingHskWidget";
import AdminPanel from "./components/AdminPanel";
import WeatherWidget from "./components/WeatherWidget";
import FloatingMapButton from "./components/FloatingMapButton";
import ThemeToggle from "./components/ThemeToggle";
import "./styles/tokens.css";
import "./App.css";
import "./frotask-shell.css";
import "./responsive.css";
import "./components/auth.css";
import "./components/hsk/hsk.css";
import "./components/team-handover.css";
import "./styles/ui-polish.css";

function ProfileMissingScreen({ currentUser, loginPortal, onUseHskLogin, onLogout }) {
  return (
    <div className="app-loading-screen">
      <div className="profile-missing-card">
        <h2>Profile not found</h2>
        <p>
          You are signed in as <strong>{currentUser.email}</strong>, but Firestore has no
          matching profile at <code>users/{currentUser.uid}</code>.
        </p>
        <ul>
          <li>In Firestore, create document <strong>users/{currentUser.uid}</strong> (use the UID from Authentication, not the email).</li>
          <li>Add fields: <strong>role</strong>, <strong>isActive</strong> (true), <strong>email</strong>, <strong>displayName</strong>.</li>
          <li>Housekeeping staff: set <strong>role</strong> to <code>housekeeping</code> and use the <strong>Housekeeping (HSK)</strong> login.</li>
          <li>Admin: set <strong>role</strong> to <code>admin</code> and use the main Sign In (Reception) or HSK login for the HSK Dashboard.</li>
        </ul>
        {loginPortal !== "housekeeping" && (
          <button type="button" className="hsk-portal-switch" onClick={onUseHskLogin}>
            Switch to Housekeeping (HSK) login
          </button>
        )}
        <button type="button" className="hsk-login-back" onClick={onLogout}>
          Back to login
        </button>
      </div>
    </div>
  );
}

function App() {
  const { currentUser, userProfile, loading, error } = useAuth();
  const [loginError, setLoginError] = useState("");
  const [loginPortal, setLoginPortal] = useState(
    () => sessionStorage.getItem("loginPortal") || "reception"
  );
  const [profileWait, setProfileWait] = useState(true);

  useEffect(() => {
    sessionStorage.setItem("loginPortal", loginPortal);
  }, [loginPortal]);

  useEffect(() => {
    if (!currentUser) {
      setProfileWait(false);
      return undefined;
    }
    if (userProfile) {
      setProfileWait(false);
      return undefined;
    }
    setProfileWait(true);
    const timer = window.setTimeout(() => setProfileWait(false), 1500);
    return () => window.clearTimeout(timer);
  }, [currentUser, userProfile]);

  const handleLogout = async () => {
    await signOutUser();
    setLoginError("");
    sessionStorage.removeItem("loginPortal");
    setLoginPortal("reception");
  };

  const role = userProfile?.role ?? userProfile?.Role;
  const useHskDashboard =
    role === "housekeeping" || (role === "admin" && loginPortal === "housekeeping");

  if (loading || (currentUser && !userProfile && profileWait)) {
    return (
      <div className="app-loading-screen">
        <div className="app-loading-text">Loading…</div>
      </div>
    );
  }

  if (!currentUser) {
    if (loginPortal === "housekeeping") {
      return (
        <HskLoginForm
          onLogin={() => setLoginError("")}
          onBack={() => setLoginPortal("reception")}
          externalError={loginError || error}
        />
      );
    }
    return (
      <AuthLoginForm
        onLogin={() => setLoginError("")}
        onError={setLoginError}
        externalError={loginError || error}
        onShowHsk={() => setLoginPortal("housekeeping")}
      />
    );
  }

  if (!userProfile) {
    return (
      <ProfileMissingScreen
        currentUser={currentUser}
        loginPortal={loginPortal}
        onUseHskLogin={() => {
          handleLogout();
          setLoginPortal("housekeeping");
        }}
        onLogout={handleLogout}
      />
    );
  }

  if (useHskDashboard) {
    return (
      <HskDashboard
        currentUser={currentUser}
        userProfile={userProfile}
        isAdminView={role === "admin"}
        onSwitchToReception={() => setLoginPortal("reception")}
      />
    );
  }

  return <ChecklistApp userProfile={userProfile} currentUser={currentUser} />;
}

function ChecklistApp({ userProfile, currentUser }) {
  const profileInitials = userProfile?.initials?.trim().toUpperCase() || "";
  const displayName = userProfile?.displayName || currentUser?.displayName || currentUser?.email || "Authenticated user";
  // Admin requires BOTH the hardcoded admin email AND the Firestore role.
  const isAdmin = isAdminEmail(currentUser?.email) && userProfile?.role === "admin";
  const { isReceptionWidgetVisible, hotelInfo } = useDashboardConfig();
  const [showAdmin, setShowAdmin] = useState(false);
  const isMobile = useIsMobile();
  const [activeView, setActiveView] = useState(
    () => (typeof window !== 'undefined' && window.innerWidth <= 1024 ? 'hub' : 'checklist')
  );
  const [mobileNavOpen, setMobileNavOpen] = useState(false);
  const [initials, setInitials] = useState("");
  const [initialsSubmitted, setInitialsSubmitted] = useState(false);
  const [showChangeInitials, setShowChangeInitials] = useState(false);
  const [newInitials, setNewInitials] = useState("");
  const [shift, setShift] = useState("Night");
  const [showInfo, setShowInfo] = useState(null);
  const [showNoteModal, setShowNoteModal] = useState(null);
  const [noteText, setNoteText] = useState("");
  const [showInitialsModal, setShowInitialsModal] = useState(false);
  const [showDowntimeInfo, setShowDowntimeInfo] = useState(false);
  const [showHandoverModal, setShowHandoverModal] = useState(false);
  const [showHandoverFullscreen, setShowHandoverFullscreen] = useState(false);
  const [handoverDate, setHandoverDate] = useState(new Date().toISOString().split('T')[0]);
  const [handoverNotes, setHandoverNotes] = useState("");
  const [savedHandovers, setSavedHandovers] = useState({});
  const [wakeUpCalls, setWakeUpCalls] = useState([]);
  const [showWakeUpModal, setShowWakeUpModal] = useState(false);
  const [showWakeUpFullscreen, setShowWakeUpFullscreen] = useState(false);
  const [newWakeUpCall, setNewWakeUpCall] = useState({
    roomNumber: '',
    time: '',
    notes: '',
    date: new Date().toISOString().split('T')[0]
  });
  const [breakfastTimes, setBreakfastTimes] = useState({ start: '07:00', end: '11:00' });
  const [pricingInfo, setPricingInfo] = useState({ ...DEFAULT_PRICING });
  const [showBreakfastModal, setShowBreakfastModal] = useState(false);
  const [showWelcomeModal, setShowWelcomeModal] = useState(false);
  const [showCelebrationModal, setShowCelebrationModal] = useState(false);
  const [lastCompletedShift, setLastCompletedShift] = useState('');

  // Use the real-time checklist hook
  const {
    tasks,
    downtimeChecklist,
    instructions,
    loading,
    error,
    toggleTask,
    toggleTaskInProgress,
    updateTaskNote,
    toggleDowntimeTask,
    resetAll
  } = useRealtimeChecklist(shift, initials);

  // Subscribe to Firebase data
  useEffect(() => {
    const unsubscribeHandovers = subscribeToHandoverNotes(setSavedHandovers);
    const unsubscribeWakeUpCalls = subscribeToWakeUpCalls(setWakeUpCalls);
    const unsubscribeBreakfastTimes = subscribeToBreakfastTimes(setBreakfastTimes);
    const unsubscribePricingInfo = subscribeToPricingInfo(setPricingInfo);

    return () => {
      unsubscribeHandovers();
      unsubscribeWakeUpCalls();
      unsubscribeBreakfastTimes();
      unsubscribePricingInfo();
    };
  }, []);

  // Load handover notes when date changes
  useEffect(() => {
    getHandoverNotes(handoverDate).then(setHandoverNotes);
  }, [handoverDate]);

  // Check for shift completion and trigger celebration
  useEffect(() => {
    if (tasks.length > 0 && tasks.every(task => task.completed)) {
      const currentShiftKey = `${shift}-${new Date().toDateString()}`;
      if (lastCompletedShift !== currentShiftKey) {
        setShowCelebrationModal(true);
        setLastCompletedShift(currentShiftKey);
      }
    }
  }, [tasks, shift, lastCompletedShift]);

  // Prefer verified profile initials when they are available from Firebase.
  useEffect(() => {
    if (profileInitials) {
      setInitials(profileInitials);
      setInitialsSubmitted(true);
    }
  }, [profileInitials]);

  // Close the topmost open modal on Escape.
  useEffect(() => {
    const handleKeyDown = (event) => {
      if (event.key !== 'Escape') return;
      if (showCelebrationModal) return setShowCelebrationModal(false);
      if (showWelcomeModal) return setShowWelcomeModal(false);
      if (showNoteModal) { setShowNoteModal(null); setNoteText(''); return; }
      if (showInitialsModal) return setShowInitialsModal(false);
      if (showDowntimeInfo) return setShowDowntimeInfo(false);
      if (showInfo) return setShowInfo(null);
      if (showWakeUpModal) return setShowWakeUpModal(false);
      if (showWakeUpFullscreen) return setShowWakeUpFullscreen(false);
      if (showHandoverModal) return setShowHandoverModal(false);
      if (showHandoverFullscreen) return setShowHandoverFullscreen(false);
      if (mobileNavOpen) return setMobileNavOpen(false);
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [
    showCelebrationModal, showWelcomeModal, showNoteModal, showInitialsModal,
    showDowntimeInfo, showInfo, showWakeUpModal, showWakeUpFullscreen,
    showHandoverModal, showHandoverFullscreen, mobileNavOpen,
  ]);

  const handleNavSelect = useCallback((viewId) => {
    setActiveView(viewId);
    setMobileNavOpen(false);
  }, []);

  const handleMobileTasks = useCallback(() => {
    setActiveView('checklist');
  }, []);

  const handleMobileHsk = useCallback(() => {
    document.querySelector('.floating-hsk-button')?.click();
  }, []);

  const handleMobileExplore = useCallback(() => {
    document.querySelector('.floating-map-button')?.click();
  }, []);

  const navItems = useMemo(() => {
    const items = [
      ...(isMobile ? [{ id: 'hub', icon: 'dashboard', label: 'Operations Hub', always: true }] : []),
      { id: 'checklist', icon: 'checklist', label: 'Checklist', always: true },
      { id: 'pricing', icon: 'payments', label: 'Pricing', widget: 'pricing' },
      { id: 'hotel-info', icon: 'hotel', label: 'Hotel Info', widget: 'hotel-info' },
      { id: 'times', icon: 'schedule', label: 'Times', widget: 'hotel-times' },
      { id: 'wake-up', icon: 'alarm_on', label: 'Wake-Up', widget: 'wakeup' },
      { id: 'handover', icon: 'history_edu', label: 'Handover Log', widgets: ['handover-daily', 'team-handovers'] },
    ];
    return items.filter((item) => {
      if (item.always) return true;
      if (item.widgets) return item.widgets.some((w) => isReceptionWidgetVisible(w));
      return isReceptionWidgetVisible(item.widget);
    });
  }, [isMobile, isReceptionWidgetVisible]);

  // Handle initials submit
  const handleInitialsSubmit = (e) => {
    e.preventDefault();
    const validation = validateUserInput(initials, 'initials');
    if (!validation.valid) {
      alert(validation.error);
      return;
    }
    setInitials(validation.value);
    setInitialsSubmitted(true);
    setShowWelcomeModal(true);
  };

  // Progress calculation - memoized for performance
  const percent = useMemo(() => 
    tasks.length ? Math.round((tasks.filter((t) => t.completed).length / tasks.length) * 100) : 0,
    [tasks]
  );

  const handleShiftChange = useCallback((newShift) => {
    setShift(newShift);
    setShowInfo(null);
  }, []);

  const handleNote = useCallback((id) => {
    const task = tasks.find(t => t.id === id);
    setNoteText(task?.note || "");
    setShowNoteModal(id);
  }, [tasks]);

  const saveNote = useCallback(() => {
    if (showNoteModal) {
      const validation = validateUserInput(noteText, 'notes');
      if (!validation.valid) {
        alert(validation.error);
        return;
      }
      updateTaskNote(showNoteModal, validation.value);
      setShowNoteModal(null);
      setNoteText("");
    }
  }, [showNoteModal, noteText, updateTaskNote]);

  const cancelNote = useCallback(() => {
    setShowNoteModal(null);
    setNoteText("");
  }, []);

  const handleResetAll = useCallback(() => {
    if (window.confirm("Are you sure you want to reset all tasks? This cannot be undone.")) {
      resetAll();
      setShowInfo(null);
    }
  }, [resetAll]);

  const handleLogout = async () => {
    await signOutUser();
    setInitials("");
    setInitialsSubmitted(false);
    setShowChangeInitials(false);
    setNewInitials("");
  };

  // Handover functions
  const loadHandoverNotes = useCallback(async (date) => {
    const notes = await getHandoverNotes(date);
    setHandoverNotes(notes);
  }, []);

  const saveHandoverNotes = useCallback(async () => {
    try {
      const validation = validateUserInput(handoverNotes, 'longText');
      const safeNotes = validation.valid ? validation.value : handoverNotes.substring(0, 10000);
      await saveHandoverNotesToDB(handoverDate, safeNotes);
      setShowHandoverModal(false);
    } catch (error) {
      console.error('Error saving handover notes:', error);
      alert('Failed to save handover notes. Please try again.');
    }
  }, [handoverDate, handoverNotes]);

  const openHandoverModal = useCallback(() => {
    setShowHandoverModal(true);
  }, []);

  const handleDateChange = useCallback((newDate) => {
    setHandoverDate(newDate);
    loadHandoverNotes(newDate);
  }, [loadHandoverNotes]);

  const deleteHandoverNotes = useCallback(async (dateToDelete) => {
    if (window.confirm(`Are you sure you want to delete handover notes for ${new Date(dateToDelete).toLocaleDateString('en-GB')}? This cannot be undone.`)) {
      try {
        await deleteHandoverNotesFromDB(dateToDelete);
        
        // If we're deleting the currently selected date, clear the notes
        if (dateToDelete === handoverDate) {
          setHandoverNotes("");
        }
        
        return true;
      } catch (error) {
        console.error('Error deleting handover notes:', error);
        alert('Failed to delete handover notes. Please try again.');
        return false;
      }
    }
    return false;
  }, [handoverDate]);

  // Bulk operations for handover notes
  const deleteAllHandoverNotes = useCallback(async () => {
    if (window.confirm(`Are you sure you want to delete ALL ${Object.keys(savedHandovers).length} handover notes? This cannot be undone.`)) {
      try {
        // Delete all handover notes by setting each one to empty
        const deletePromises = Object.keys(savedHandovers).map(date => 
          deleteHandoverNotesFromDB(date)
        );
        await Promise.all(deletePromises);
        setHandoverNotes("");
      } catch (error) {
        console.error('Error deleting all handover notes:', error);
        alert('Failed to delete all handover notes. Please try again.');
      }
    }
  }, [savedHandovers]);

  const deleteOldHandoverNotes = useCallback(async () => {
    const sevenDaysAgo = new Date();
    sevenDaysAgo.setDate(sevenDaysAgo.getDate() - 7);
    const cutoffDate = sevenDaysAgo.toISOString().split('T')[0];
    
    const oldDates = Object.keys(savedHandovers).filter(date => date < cutoffDate);
    
    if (oldDates.length === 0) {
      alert('No old handover notes to delete.');
      return;
    }
    
    if (window.confirm(`Are you sure you want to delete ${oldDates.length} handover notes older than 7 days? This cannot be undone.`)) {
      try {
        const deletePromises = oldDates.map(date => deleteHandoverNotesFromDB(date));
        await Promise.all(deletePromises);
      } catch (error) {
        console.error('Error deleting old handover notes:', error);
        alert('Failed to delete old handover notes. Please try again.');
      }
    }
  }, [savedHandovers]);

  // Bulk operations for wake-up calls
  const completeAllPendingWakeUpCalls = useCallback(async () => {
    const pendingCalls = wakeUpCalls.filter(call => !call.completed);
    
    if (pendingCalls.length === 0) {
      alert('No pending wake-up calls to complete.');
      return;
    }
    
    if (window.confirm(`Are you sure you want to mark all ${pendingCalls.length} pending wake-up calls as completed?`)) {
      try {
        const updatedCalls = wakeUpCalls.map(call => 
          !call.completed ? { ...call, completed: true, completedBy: initials } : call
        );
        await saveWakeUpCalls(updatedCalls);
      } catch (error) {
        console.error('Error completing all wake-up calls:', error);
        alert('Failed to complete all wake-up calls. Please try again.');
      }
    }
  }, [wakeUpCalls, initials]);

  // Breakfast time functions
  const saveBreakfastTimes = useCallback(async () => {
    try {
      await saveBreakfastTimesToDB(breakfastTimes);
      setShowBreakfastModal(false);
    } catch (error) {
      console.error('Error saving breakfast times:', error);
      alert('Failed to save breakfast times. Please try again.');
    }
  }, [breakfastTimes]);

  const cancelBreakfastEdit = useCallback(async () => {
    try {
      const savedTimes = await getBreakfastTimes();
      setBreakfastTimes(savedTimes);
      setShowBreakfastModal(false);
    } catch (error) {
      console.error('Error getting breakfast times:', error);
      setBreakfastTimes({ start: '07:00', end: '11:00' });
      setShowBreakfastModal(false);
    }
  }, []);

  // Wake-up call functions
  const addWakeUpCall = useCallback(async () => {
    if (!newWakeUpCall.roomNumber || !newWakeUpCall.time) {
      alert('Please enter both room number(s) and wake-up time.');
      return;
    }

    const timeValidation = validateUserInput(newWakeUpCall.time, 'time');
    if (!timeValidation.valid) {
      alert(timeValidation.error);
      return;
    }

    // Parse and validate each room number
    const rawRooms = newWakeUpCall.roomNumber
      .split(/[,;\s]+/)
      .map(room => room.trim())
      .filter(room => room.length > 0);

    const roomNumbers = [];
    for (const room of rawRooms) {
      const roomValidation = validateUserInput(room, 'roomNumber');
      if (!roomValidation.valid) {
        alert(`Invalid room number "${room}": ${roomValidation.error}`);
        return;
      }
      roomNumbers.push(roomValidation.value);
    }

    if (roomNumbers.length === 0) {
      alert('Please enter valid room number(s).');
      return;
    }

    const notesValidation = validateUserInput(newWakeUpCall.notes || '', 'notes');
    const safeNotes = notesValidation.valid ? notesValidation.value : '';

    // Create separate wake-up call for each room
    const newCalls = roomNumbers.map(roomNumber => ({
      ...newWakeUpCall,
      id: Date.now() + Math.random(),
      roomNumber,
      time: timeValidation.value,
      notes: safeNotes,
      createdBy: initials,
      completed: false
    }));

    const updatedCalls = [...wakeUpCalls, ...newCalls].sort((a, b) => {
      // Sort by date first, then by time
      if (a.date !== b.date) {
        return new Date(a.date) - new Date(b.date);
      }
      return a.time.localeCompare(b.time);
    });

    try {
      await saveWakeUpCalls(updatedCalls);
      
      setNewWakeUpCall({
        roomNumber: '',
        time: '',
        notes: '',
        date: new Date().toISOString().split('T')[0]
      });
      setShowWakeUpModal(false);
    } catch (error) {
      console.error('Error saving wake-up calls:', error);
      alert('Failed to save wake-up call. Please try again.');
    }
  }, [newWakeUpCall, wakeUpCalls, initials]);

  const deleteWakeUpCall = useCallback(async (id) => {
    if (window.confirm('Are you sure you want to delete this wake-up call?')) {
      try {
        const updatedCalls = wakeUpCalls.filter(call => call.id !== id);
        await saveWakeUpCalls(updatedCalls);
      } catch (error) {
        console.error('Error deleting wake-up call:', error);
        alert('Failed to delete wake-up call. Please try again.');
      }
    }
  }, [wakeUpCalls]);

  const toggleWakeUpCallComplete = useCallback(async (id) => {
    try {
      const updatedCalls = wakeUpCalls.map(call => 
        call.id === id 
          ? { ...call, completed: !call.completed, completedBy: call.completed ? null : initials }
          : call
      );
      await saveWakeUpCalls(updatedCalls);
    } catch (error) {
      console.error('Error updating wake-up call:', error);
      alert('Failed to update wake-up call. Please try again.');
    }
  }, [wakeUpCalls, initials]);

  const clearOldWakeUpCalls = useCallback(async () => {
    const today = new Date().toISOString().split('T')[0];
    const activeCalls = wakeUpCalls.filter(call => call.date >= today);
    
    if (activeCalls.length === wakeUpCalls.length) {
      alert('No old wake-up calls to clear.');
      return;
    }

    if (window.confirm(`Clear ${wakeUpCalls.length - activeCalls.length} old wake-up calls?`)) {
      try {
        await saveWakeUpCalls(activeCalls);
      } catch (error) {
        console.error('Error clearing old wake-up calls:', error);
        alert('Failed to clear old wake-up calls. Please try again.');
      }
    }
  }, [wakeUpCalls]);

  // Show initials input after login if not set yet
  if (!initialsSubmitted) {
    return (
      <div className="initials-gate">
        <form className="initials-gate-card" onSubmit={handleInitialsSubmit}>
          <div className="initials-gate-icon" aria-hidden="true">
            <span className="material-symbols-outlined">badge</span>
          </div>
          <h2 className="initials-gate-title">Who's on shift?</h2>
          <p className="initials-gate-subtitle">
            Your initials are attached to every task you complete, so the team knows who did what.
          </p>
          <input
            className="initials-gate-input"
            type="text"
            placeholder="AG"
            value={initials}
            onChange={e => setInitials(e.target.value.replace(/[^a-zA-Z]/g, '').toUpperCase())}
            maxLength={4}
            required
            autoFocus
            aria-label="Your initials"
          />
          <button type="submit" className="initials-gate-submit">Start shift</button>
          <button type="button" className="initials-gate-logout" onClick={handleLogout}>
            Log out
          </button>
        </form>
      </div>
    );
  }

    return (
    <div className="frotask-app">
      <aside className={`app-nav-sidebar ${mobileNavOpen ? 'is-open' : ''}`}>
        <div className="app-nav-brand">
          <div className="app-nav-brand-row">
            <div className="app-nav-logo">
              <span className="material-symbols-outlined">hotel</span>
            </div>
            <h1 className="app-nav-title">FROTASK</h1>
          </div>
          <p className="app-nav-subtitle">Management Portal</p>
        </div>

        <nav className="app-nav-list" aria-label="Main navigation">
          {navItems.map((item) => (
            <button
              key={item.id}
              type="button"
              className={`app-nav-link ${activeView === item.id ? 'is-active' : ''}`}
              onClick={() => handleNavSelect(item.id)}
            >
              <span className="material-symbols-outlined">{item.icon}</span>
              <span>{item.label}</span>
            </button>
          ))}
        </nav>

        {isReceptionWidgetVisible('handover-daily') && (
          <div className="app-nav-footer">
            <button type="button" className="app-nav-new-handover" onClick={openHandoverModal}>
              <span className="material-symbols-outlined">add</span>
              <span>New Handover</span>
            </button>
          </div>
        )}
      </aside>

      {mobileNavOpen && (
        <button
          type="button"
          className="app-nav-overlay"
          aria-label="Close navigation"
          onClick={() => setMobileNavOpen(false)}
        />
      )}

      <header className="app-top-bar">
        <div className="app-top-bar-left">
          <button
            type="button"
            className="app-nav-mobile-toggle"
            aria-label="Open navigation"
            onClick={() => setMobileNavOpen(true)}
          >
            <span className="material-symbols-outlined">menu</span>
          </button>
          <h2 className="app-top-bar-title">
            {isMobile
              ? (activeView === 'checklist' ? `${shift} Shift` : activeView === 'hub' ? 'Operations Hub' : 'Front Desk Operations')
              : 'Front Desk Operations'}
          </h2>
          <div className="app-shift-selector app-shift-selector-top">
            {Object.keys(checklists).map((shiftName) => (
              <button
                key={shiftName}
                type="button"
                onClick={() => handleShiftChange(shiftName)}
                className={`app-shift-btn ${shift === shiftName ? 'is-active' : ''}`}
              >
                {shiftName}
              </button>
            ))}
          </div>
        </div>

        <div className="app-top-bar-right">
          <div className="app-top-bar-utilities">
            <WeatherWidget />
            <ThemeToggle />
          </div>
          <div className="app-top-bar-header-actions">
            {isAdmin && (
              <button type="button" className="ft-top-link" onClick={() => setShowAdmin(true)}>Admin</button>
            )}
            {activeView === 'checklist' && (
              <button type="button" className="ft-top-link" onClick={handleResetAll}>Reset All</button>
            )}
            <button
              type="button"
              className="ft-user-pill"
              title="Change initials"
              onClick={() => {
                setNewInitials(initials);
                setShowInitialsModal(true);
              }}
            >
              {initials} <span className="ft-user-pill-role">Front Desk</span>
            </button>
            <button type="button" className="ft-top-link" onClick={handleLogout}>Log Out</button>
          </div>
        </div>
      </header>

      <main className="frotask-main">
        {activeView === 'checklist' ? (
        <div className="frotask-main-inner">
          <section className="frotask-checklist-header">
            <div className="frotask-checklist-heading">
              <h3 className="frotask-checklist-title">{shift} Checklist</h3>
              <div className="frotask-checklist-progress-row">
                <div className="frotask-checklist-progress-track">
                  <div className="frotask-checklist-progress-fill" style={{ width: `${percent}%` }} />
                </div>
                <span className="frotask-checklist-progress-label">
                  {percent}% COMPLETE ({tasks.filter((t) => t.completed).length}/{tasks.length} TASKS)
                </span>
              </div>
              <div className="app-shift-selector frotask-mobile-shift-selector">
                {Object.keys(checklists).map((shiftName) => (
                  <button
                    key={shiftName}
                    type="button"
                    onClick={() => handleShiftChange(shiftName)}
                    className={`app-shift-btn ${shift === shiftName ? 'is-active' : ''}`}
                  >
                    {shiftName}
                  </button>
                ))}
              </div>
            </div>
          </section>

          <div className="frotask-meta-strip frotask-meta-strip-compact">
            <div className="frotask-meta-strip-info">
              <span className="meta-bar-user">
                Logged in as <strong>{displayName}</strong>
              </span>
              <span>
                {new Date().toLocaleString([], { dateStyle: "full", timeStyle: "short" })}
              </span>
            </div>
          </div>

          {/* Sync error banner (syncing itself is silent) */}
          {error && (
            <div className="sync-error-banner" role="alert">
              <span className="material-symbols-outlined" aria-hidden="true">cloud_off</span>
              <span>Offline — changes are saved locally and will sync when reconnected.</span>
            </div>
          )}

          {/* Shift instructions (read-only, set by admin) */}
          {instructions && instructions.trim() && (
            <div className="shift-instructions-card">
              <div className="shift-instructions-title">
                <span role="img" aria-label="clipboard">📋</span> {shift} Shift Notes
              </div>
              <p className="shift-instructions-text">{instructions}</p>
            </div>
          )}

          {/* Checklist tasks */}
          <div className="checklist-section-label">Shift tasks</div>
          <div className="task-list" role="list" aria-label={`${shift} checklist tasks`}>
            {loading && tasks.length === 0 && (
              [1, 2, 3, 4].map((n) => (
                <div key={n} className="task-card task-card-skeleton" aria-hidden="true">
                  <span className="skeleton-dot" />
                  <span className="skeleton-line" style={{ width: `${86 - n * 12}%` }} />
                </div>
              ))
            )}
            {!loading && tasks.length === 0 && (
              <div className="task-list-empty">
                <span className="material-symbols-outlined" aria-hidden="true">checklist</span>
                <h3>No tasks for this shift yet</h3>
                <p>Tasks appear here as soon as the {shift.toLowerCase()} checklist is set up in the admin panel.</p>
              </div>
            )}
            {tasks.map((task) => {
              const isInProgress = Boolean(task.inProgressBy);
              const isMine = task.inProgressBy === initials;
              const isCritical = task.highlighted;

              return (
                <article
                  key={task.id}
                  className={`task-card ${task.completed ? "is-completed" : ""} ${isInProgress ? "is-in-progress" : ""} ${isCritical ? "task-critical" : ""}`}
                  role="listitem"
                >
                  <label className="task-checkbox-control">
                    <input
                      className="ios-checkbox-input"
                      type="checkbox"
                      checked={task.completed}
                      onChange={() => toggleTask(task.id)}
                      aria-label={`Mark "${task.text}" as ${task.completed ? 'incomplete' : 'complete'}`}
                    />
                    <span className="ios-checkbox" aria-hidden="true"></span>
                  </label>

                  <div className="frotask-task-main">
                    <div className={`frotask-task-icon ${isInProgress || isCritical ? 'is-active' : ''}`}>
                      <span className="material-symbols-outlined">
                        {isCritical ? 'priority_high' : isInProgress ? 'pending' : 'task_alt'}
                      </span>
                    </div>
                    <div className="frotask-task-content">
                      <div className="frotask-task-title-row">
                        {isCritical && <span className="frotask-task-badge is-critical">Critical</span>}
                        {isInProgress && <span className="frotask-task-badge is-working">Working</span>}
                        <h3 className="task-title">{task.text}</h3>
                      </div>
                      {task.note && (
                        <p className="task-note-preview">{task.note}</p>
                      )}
                      {task.completed && task.doneBy && (
                        <p className="ft-task-completed-by">Completed by {task.doneBy}</p>
                      )}
                      {isInProgress && (
                        <span className="in-progress-indicator">
                          <span className="in-progress-dot" aria-hidden="true"></span>
                          {isMine ? "In progress" : `${task.inProgressBy} working`}
                        </span>
                      )}
                    </div>
                  </div>

                  <div className="task-card-actions">
                    {task.completed ? (
                      <>
                        <button
                          type="button"
                          className="ft-icon-btn ft-undo-btn"
                          onClick={() => toggleTask(task.id)}
                          aria-label={`Mark "${task.text}" as incomplete`}
                        >
                          <span className="material-symbols-outlined">undo</span>
                        </button>
                      </>
                    ) : (
                      <>
                        <button
                          className={`working-btn ${isMine ? "working-active" : (isInProgress ? "working-other" : "")}`}
                          onClick={() => toggleTaskInProgress(task.id)}
                          disabled={task.completed || (isInProgress && !isMine)}
                          title={isInProgress && !isMine ? `${task.inProgressBy} is working on this task` : isMine ? "Stop working on this task" : "Start working on this task"}
                        >
                          {isMine ? 'Finish Task' : isInProgress ? task.inProgressBy : 'Start Task'}
                        </button>
                        <button
                          className="info-btn"
                          onClick={() => setShowInfo(showInfo === task.id ? null : task.id)}
                          aria-label={`${showInfo === task.id ? 'Hide' : 'Show'} information for ${task.text}`}
                        >
                          i
                        </button>
                        <button
                          className={task.note ? "edit-note-btn ft-btn-ghost-sm" : "add-note-btn ft-btn-ghost-sm"}
                          onClick={() => handleNote(task.id)}
                          title={task.note ? "View/Edit Note" : "Add Note"}
                        >
                          {task.note ? "Edit note" : "Add note"}
                        </button>
                      </>
                    )}
                  </div>
                </article>
              );
            })}
          </div>

          {/* Downtime Reports Mini-Checklist */}
          <div className="checklist-section-label downtime-section-label">Downtime checklist</div>
          <div className="downtime-checklist">
            <div className="downtime-header">
              <div className="downtime-header-top">
                <h3 className="downtime-title">
                  Print Downtime Every 3 Hours
                </h3>
                <button
                  className="downtime-info-icon-btn"
                  onClick={() => setShowDowntimeInfo(!showDowntimeInfo)}
                  aria-label="Show downtime report instructions"
                  data-tooltip="Downtime Instructions"
                >
                  i
                </button>
              </div>
              <p className="downtime-callout">
                Important: Print and file the new downtime report every 3 hours during your shift.
              </p>
            </div>
            <div className="downtime-items">
              {downtimeChecklist.map((item) => (
                <div key={item.id} className={`downtime-item ${item.completed ? "is-completed" : ""}`}>
                  <label className="task-checkbox-control downtime-checkbox-control">
                    <input
                      className="ios-checkbox-input"
                      type="checkbox"
                      checked={item.completed}
                      onChange={() => toggleDowntimeTask(item.id)}
                      aria-label={`Mark ${item.text} as ${item.completed ? 'incomplete' : 'complete'}`}
                    />
                    <span className="ios-checkbox" aria-hidden="true"></span>
                  </label>
                  <span className={item.completed ? "downtime-text-completed" : "downtime-text"}>
                    {item.text}
                  </span>
                  {item.completed && <span className="initials-chip">{item.doneBy}</span>}
                </div>
              ))}
            </div>
          </div>

          <footer className="footer-text">
            Something broken or missing?{' '}
            <a href="mailto:ayush.gurung@scandichotels.com">Email Ayush</a>
          </footer>
        </div>
        ) : (
        <div className="frotask-main-inner">
          <ReceptionPanels
            activeView={activeView}
            hotelInfo={hotelInfo}
            breakfastTimes={breakfastTimes}
            pricingInfo={pricingInfo}
            wakeUpCalls={wakeUpCalls}
            savedHandovers={savedHandovers}
            handoverDate={handoverDate}
            currentUser={currentUser}
            isAdmin={isAdmin}
            isReceptionWidgetVisible={isReceptionWidgetVisible}
            onBreakfastEdit={() => setShowBreakfastModal(true)}
            onHandoverDateChange={handleDateChange}
            onHandoverEdit={openHandoverModal}
            onHandoverViewAll={() => setShowHandoverFullscreen(true)}
            onWakeUpAdd={() => setShowWakeUpModal(true)}
            onWakeUpViewAll={() => setShowWakeUpFullscreen(true)}
            onWakeUpToggle={toggleWakeUpCallComplete}
            onWakeUpDelete={deleteWakeUpCall}
            onWakeUpClearOld={clearOldWakeUpCalls}
            onNavigate={handleNavSelect}
          />
        </div>
        )}
      </main>

      {isMobile && (
        <MobileBottomNav
          active={activeView === 'checklist' ? 'tasks' : activeView === 'hub' ? '' : ''}
          onTasks={handleMobileTasks}
          onHsk={handleMobileHsk}
          onExplore={handleMobileExplore}
        />
      )}

      {/* Info Modal */}
      {showInfo && (() => {
        const task = tasks.find(t => t.id === showInfo) || {};
        return (
          <div
            className="info-modal-overlay"
            onClick={() => setShowInfo(null)}
          >
            <div
              className="info-modal-box"
              role="dialog"
              aria-modal="true"
              onClick={e => e.stopPropagation()} // Prevent closing when clicking inside the modal
            >
              <button className="info-modal-close" onClick={() => setShowInfo(null)} title="Close">&times;</button>
              <h3>{task.text || "Task Info"}</h3>
              <div className="info-detail">{task.info}</div>
            </div>
          </div>
        );
      })()}

      {/* Note Modal */}
      {showNoteModal && (() => {
        const task = tasks.find(t => t.id === showNoteModal) || {};
        return (
          <div
            className="info-modal-overlay"
            onClick={cancelNote}
          >
            <div
              className="note-modal-box"
              onClick={e => e.stopPropagation()}
            >
              <button className="info-modal-close" onClick={cancelNote} title="Close">&times;</button>
              <h3>{task.note ? "Edit Note" : "Add Note"}</h3>
              <textarea
                className="note-textarea"
                value={noteText}
                onChange={e => setNoteText(e.target.value)}
                placeholder="Enter your note here..."
                rows={4}
                autoFocus
              />
              <div className="note-modal-buttons">
                <button className="add-note-btn" onClick={saveNote}>
                  Save Note
                </button>
                <button className="reset-btn" onClick={cancelNote} style={{ marginRight: 0 }}>
                  Cancel
                </button>
              </div>
            </div>
          </div>
        );
      })()}

      {/* Initials Modal */}
      {showInitialsModal && (
        <div
          className="info-modal-overlay"
          onClick={() => setShowInitialsModal(false)}
        >
          <div
            className="initials-modal-box"
            onClick={e => e.stopPropagation()}
          >
            <button className="info-modal-close" onClick={() => setShowInitialsModal(false)} title="Close">&times;</button>
            <h3>Change Initials</h3>
            <form
              onSubmit={e => {
                e.preventDefault();
                const trimmedInitials = newInitials.trim().toUpperCase();
                if (trimmedInitials.length < 2) {
                  alert("Please enter at least 2 letters for initials.");
                  return;
                }
                setInitials(trimmedInitials);
                updateSessionInitials(trimmedInitials, true); // Update session with new initials
                setShowInitialsModal(false);
              }}
            >
              <input
                type="text"
                className="initials-input"
                value={newInitials}
                onChange={e => setNewInitials(e.target.value.replace(/[^a-zA-Z]/g, '').toUpperCase())}
                placeholder="Enter initials"
                maxLength={4}
                autoFocus
                required
              />
              <div className="note-modal-buttons">
                <button type="submit" className="add-note-btn">
                  Save
                </button>
                <button type="button" className="reset-btn" onClick={() => setShowInitialsModal(false)} style={{ marginRight: 0 }}>
                  Cancel
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Downtime Info Modal */}
      {showDowntimeInfo && (
        <div
          className="info-modal-overlay"
          onClick={() => setShowDowntimeInfo(false)}
        >
          <div
            className="info-modal-box"
            role="dialog"
            aria-modal="true"
            aria-label="Downtime report instructions"
            onClick={e => e.stopPropagation()}
          >
            <button className="info-modal-close" onClick={() => setShowDowntimeInfo(false)} title="Close">&times;</button>
            <h3>📊 Downtime Reports Instructions</h3>
            <div className="downtime-info-content">
              <div className="downtime-info-section">
                <div className="downtime-info-header">
                  <span className="downtime-info-icon">🖨️</span>
                  <h4>Print New Report</h4>
                </div>
                <ol className="downtime-info-steps">
                  <li>Open <strong>Cloud Opera</strong> system</li>
                  <li>Navigate to <strong>Reports</strong> → <strong>Shift reports</strong></li>
                  <li>Print the <strong>downtime</strong> from there</li>
                </ol>
              </div>

              <div className="downtime-info-section">
                <div className="downtime-info-header">
                  <span className="downtime-info-icon">📁</span>
                  <h4>File the Report</h4>
                </div>
                <ol className="downtime-info-steps">
                  <li>Locate the <strong>downtime report cabinet</strong></li>
                  <li>Remove the <strong>old downtime report</strong></li>
                  <li>Replace with the <strong>newly printed report</strong></li>
                  <li>Ensure proper chronological filing</li>
                </ol>
              </div>

              <div className="downtime-info-section downtime-info-important">
                <div className="downtime-info-header">
                  <span className="downtime-info-icon">⚠️</span>
                  <h4>Important Notes</h4>
                </div>
                <ul className="downtime-info-points">
                  <li><strong>Critical for emergencies:</strong> These reports provide essential system status information</li>
                  <li><strong>Required frequency:</strong> Must be printed every 3 hours during shift</li>
                  <li><strong>Tracking:</strong> Use the checkboxes above to track each 3-hour period</li>
                  <li><strong>Compliance:</strong> Essential for audit and regulatory requirements</li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Handover Modal */}
      {showHandoverModal && (
        <div
          className="handover-modal-overlay"
          onClick={() => setShowHandoverModal(false)}
        >
          <div
            className="handover-modal-container"
            onClick={e => e.stopPropagation()}
          >
            <div className="handover-modal-header">
              <h2>📝 Daily Handover Management</h2>
              <button className="handover-modal-close" onClick={() => setShowHandoverModal(false)} title="Close">
                &times;
              </button>
            </div>

            <div className="handover-modal-content">
              {/* Left side - Date selection and navigation */}
              <div className="handover-sidebar">
                <div className="handover-current-date">
                  <h3>Select Date</h3>
                  <input
                    type="date"
                    value={handoverDate}
                    onChange={(e) => handleDateChange(e.target.value)}
                    className="handover-main-date-input"
                  />
                  <div className="handover-date-display">
                    {new Date(handoverDate).toLocaleDateString('en-GB', { 
                      weekday: 'long', 
                      year: 'numeric', 
                      month: 'long', 
                      day: 'numeric' 
                    })}
                  </div>
                </div>

                <div className="handover-quick-nav">
                  <h4>Quick Navigation</h4>
                  <div className="handover-nav-buttons">
                    <button
                      className="handover-nav-btn"
                      onClick={() => {
                        const yesterday = new Date();
                        yesterday.setDate(yesterday.getDate() - 1);
                        handleDateChange(yesterday.toISOString().split('T')[0]);
                      }}
                    >
                      ← Yesterday
                    </button>
                    <button
                      className="handover-nav-btn"
                      onClick={() => handleDateChange(new Date().toISOString().split('T')[0])}
                    >
                      Today
                    </button>
                    <button
                      className="handover-nav-btn"
                      onClick={() => {
                        const tomorrow = new Date();
                        tomorrow.setDate(tomorrow.getDate() + 1);
                        handleDateChange(tomorrow.toISOString().split('T')[0]);
                      }}
                    >
                      Tomorrow →
                    </button>
                  </div>
                </div>

                <div className="handover-history">
                  <h4>Recent Days with Notes</h4>
                  <div className="handover-history-list">
                    {Object.keys(savedHandovers)
                      .sort((a, b) => new Date(b) - new Date(a))
                      .slice(0, 8)
                      .map(date => (
                        <div
                          key={date}
                          className={`handover-history-item ${date === handoverDate ? 'active' : ''}`}
                        >
                          <button
                            className="handover-history-btn"
                            onClick={() => handleDateChange(date)}
                          >
                            <div className="handover-history-date">
                              {new Date(date).toLocaleDateString('en-GB', { 
                                month: 'short', 
                                day: 'numeric' 
                              })}
                            </div>
                            <div className="handover-history-preview">
                              {savedHandovers[date].substring(0, 40)}...
                            </div>
                          </button>
                          <button
                            className="handover-history-delete"
                            onClick={(e) => {
                              e.stopPropagation();
                              deleteHandoverNotes(date);
                            }}
                            title={`Delete notes for ${new Date(date).toLocaleDateString('en-GB')}`}
                          >
                            🗑️
                          </button>
                        </div>
                      ))}
                  </div>
                  
                  <div className="handover-stats-detailed">
                    <div className="handover-stat-item">
                      <span className="handover-stat-number">{Object.keys(savedHandovers).length}</span>
                      <span className="handover-stat-label">Total Days</span>
                    </div>
                    <div className="handover-stat-item">
                      <span className="handover-stat-number">
                        {Object.keys(savedHandovers).filter(date => {
                          const noteDate = new Date(date);
                          const weekAgo = new Date();
                          weekAgo.setDate(weekAgo.getDate() - 7);
                          return noteDate >= weekAgo;
                        }).length}
                      </span>
                      <span className="handover-stat-label">This Week</span>
                    </div>
                  </div>

                  {Object.keys(savedHandovers).length > 0 && (
                    <div className="handover-bulk-actions">
                      <h4>Bulk Actions</h4>
                      <button
                        className="handover-bulk-delete-btn"
                        onClick={deleteAllHandoverNotes}
                      >
                        🗑️ Delete All Notes
                      </button>
                      <button
                        className="handover-bulk-delete-old-btn"
                        onClick={deleteOldHandoverNotes}
                      >
                        🧹 Delete Old Notes (7+ days)
                      </button>
                    </div>
                  )}
                </div>
              </div>

              {/* Right side - Notes editing */}
              <div className="handover-editor">
                <div className="handover-editor-header">
                  <h3>
                    {savedHandovers[handoverDate] ? '📝 Edit Notes' : '➕ Add New Notes'}
                  </h3>
                  <div className="handover-editor-info">
                    {savedHandovers[handoverDate] && (
                      <span className="handover-word-count">
                        {handoverNotes.split(' ').filter(word => word.length > 0).length} words
                      </span>
                    )}
                  </div>
                </div>

                <textarea
                  className="handover-main-textarea"
                  value={handoverNotes}
                  onChange={e => setHandoverNotes(e.target.value)}
                  placeholder={`What happened on ${new Date(handoverDate).toLocaleDateString('en-GB')}?

🏨 Hotel Operations:
• Guest requests and special needs
• Room status updates
• Equipment issues

🔧 Maintenance & Repairs:
• Broken or malfunctioning equipment
• Scheduled maintenance
• Repair requests

👥 Staff & Schedule:
• Staff schedule changes
• Important announcements
• Training or meetings

📦 Supplies & Inventory:
• Low stock items
• Supply deliveries
• Restocking needs

⚠️ Incidents & Issues:
• Guest complaints
• Safety incidents
• System problems

📋 Next Shift Notes:
• Urgent tasks for next shift
• Follow-up required
• Special instructions`}
                  rows={20}
                  autoFocus
                />

                <div className="handover-editor-actions">
                  <button className="handover-save-btn" onClick={saveHandoverNotes}>
                    💾 Save Notes
                  </button>
                  <button className="handover-cancel-btn" onClick={() => setShowHandoverModal(false)}>
                    ❌ Cancel
                  </button>
                  {savedHandovers[handoverDate] && (
                    <button 
                      className="handover-delete-btn"
                      onClick={() => deleteHandoverNotes(handoverDate)}
                    >
                      🗑️ Delete Notes
                    </button>
                  )}
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Wake-Up Call Modal */}
      {showWakeUpModal && (
        <div
          className="info-modal-overlay"
          onClick={() => setShowWakeUpModal(false)}
        >
          <div
            className="wakeup-modal-box"
            onClick={e => e.stopPropagation()}
          >
            <button className="info-modal-close" onClick={() => setShowWakeUpModal(false)} title="Close">&times;</button>
            <h3>☎️ Add Wake-Up Call</h3>
            <form
              onSubmit={e => {
                e.preventDefault();
                addWakeUpCall();
              }}
            >
              <div className="wakeup-form-group">
                <label htmlFor="roomNumber">Room Number(s)</label>
                <input
                  id="roomNumber"
                  type="text"
                  className="wakeup-input"
                  value={newWakeUpCall.roomNumber}
                  onChange={e => setNewWakeUpCall(prev => ({ ...prev, roomNumber: e.target.value }))}
                  placeholder="e.g. 102 or 102, 103, 205"
                  autoFocus
                  required
                />
                <div className="wakeup-input-help">
                  Separate multiple rooms with commas (e.g., 102, 103, 205)
                </div>
              </div>
              
              <div className="wakeup-form-group">
                <label htmlFor="wakeupTime">Wake-Up Time</label>
                <input
                  id="wakeupTime"
                  type="time"
                  className="wakeup-input"
                  value={newWakeUpCall.time}
                  onChange={e => setNewWakeUpCall(prev => ({ ...prev, time: e.target.value }))}
                  required
                />
              </div>
              
              <div className="wakeup-form-group">
                <label htmlFor="wakeupDate">Date</label>
                <input
                  id="wakeupDate"
                  type="date"
                  className="wakeup-input"
                  value={newWakeUpCall.date}
                  onChange={e => setNewWakeUpCall(prev => ({ ...prev, date: e.target.value }))}
                  min={new Date().toISOString().split('T')[0]}
                  required
                />
              </div>
              
              <div className="wakeup-form-group">
                <label htmlFor="wakeupNotes">Notes (Optional)</label>
                <textarea
                  id="wakeupNotes"
                  className="wakeup-textarea"
                  value={newWakeUpCall.notes}
                  onChange={e => setNewWakeUpCall(prev => ({ ...prev, notes: e.target.value }))}
                  placeholder="Special instructions or guest preferences..."
                  rows={3}
                />
              </div>
              
              <div className="note-modal-buttons">
                <button type="submit" className="add-note-btn">
                  Add Wake-Up Call
                </button>
                <button type="button" className="reset-btn" onClick={() => setShowWakeUpModal(false)} style={{ marginRight: 0 }}>
                  Cancel
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Wake-Up Calls Fullscreen Modal */}
      {showWakeUpFullscreen && (
        <div
          className="wakeup-fullscreen-overlay"
          onClick={() => setShowWakeUpFullscreen(false)}
        >
          <div
            className="wakeup-fullscreen-container" role="dialog" aria-modal="true" aria-label="All wake-up calls"
            onClick={e => e.stopPropagation()}
          >
            <div className="wakeup-fullscreen-header">
              <h2>☎️ All Wake-Up Calls</h2>
              <div className="wakeup-fullscreen-actions">
                <button
                  className="wakeup-add-btn"
                  onClick={() => {
                    setShowWakeUpFullscreen(false);
                    setShowWakeUpModal(true);
                  }}
                >
                  + Add New
                </button>
                <button className="wakeup-fullscreen-close" onClick={() => setShowWakeUpFullscreen(false)} title="Close">
                  &times;
                </button>
              </div>
            </div>

            <div className="wakeup-fullscreen-content">
              <div className="wakeup-fullscreen-stats">
                <div className="wakeup-fullscreen-stat">
                  <span className="stat-number">{wakeUpCalls.filter(call => !call.completed && call.date >= new Date().toISOString().split('T')[0]).length}</span>
                  <span className="stat-label">Pending Calls</span>
                </div>
                <div className="wakeup-fullscreen-stat">
                  <span className="stat-number">{wakeUpCalls.filter(call => call.completed).length}</span>
                  <span className="stat-label">Completed</span>
                </div>
                <div className="wakeup-fullscreen-stat">
                  <span className="stat-number">{wakeUpCalls.length}</span>
                  <span className="stat-label">Total Calls</span>
                </div>
              </div>

              <div className="wakeup-fullscreen-filters">
                <div className="wakeup-filter-tabs">
                  <button className="wakeup-filter-tab active">All Calls</button>
                  <button className="wakeup-filter-tab">Today</button>
                  <button className="wakeup-filter-tab">Pending</button>
                  <button className="wakeup-filter-tab">Completed</button>
                </div>
              </div>

              <div className="wakeup-fullscreen-table-container is-mobile-cards">
                <table className="wakeup-fullscreen-table">
                  <thead>
                    <tr>
                      <th>Room</th>
                      <th>Date</th>
                      <th>Time</th>
                      <th>Notes</th>
                      <th>Created By</th>
                      <th>Status</th>
                      <th>Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {wakeUpCalls
                      .sort((a, b) => {
                        // Sort by date first, then by time
                        if (a.date !== b.date) {
                          return new Date(a.date) - new Date(b.date);
                        }
                        return a.time.localeCompare(b.time);
                      })
                      .map(call => (
                        <tr key={call.id} className={call.completed ? 'wakeup-row-completed' : ''}>
                          <td className="wakeup-room-cell" data-label="Room">
                            <span className="wakeup-room-number">Room {call.roomNumber}</span>
                          </td>
                          <td className="wakeup-date-cell" data-label="Date">
                            {new Date(call.date).toLocaleDateString('en-GB', { 
                              weekday: 'short', 
                              month: 'short', 
                              day: 'numeric' 
                            })}
                            {call.date === new Date().toISOString().split('T')[0] && (
                              <span className="wakeup-today-badge">Today</span>
                            )}
                          </td>
                          <td className="wakeup-time-cell" data-label="Time">
                            <span className="wakeup-time-display">{call.time}</span>
                          </td>
                          <td className="wakeup-notes-cell" data-label="Notes">
                            {call.notes ? (
                              <span className="wakeup-notes-preview" title={call.notes}>
                                {call.notes.length > 30 ? call.notes.substring(0, 30) + '...' : call.notes}
                              </span>
                            ) : (
                              <span className="wakeup-no-notes">No notes</span>
                            )}
                          </td>
                          <td className="wakeup-created-cell" data-label="Created by">
                            <span className="wakeup-initials-small">{call.createdBy}</span>
                          </td>
                          <td className="wakeup-status-cell" data-label="Status">
                            {call.completed ? (
                              <span className="wakeup-status-completed">
                                ✅ Completed by {call.completedBy}
                              </span>
                            ) : (
                              <span className="wakeup-status-pending">
                                ⏰ Pending
                              </span>
                            )}
                          </td>
                          <td className="wakeup-actions-cell" data-label="Actions">
                            <div className="wakeup-action-buttons">
                              <button
                                className={`wakeup-toggle-btn ${call.completed ? 'completed' : 'pending'}`}
                                onClick={() => toggleWakeUpCallComplete(call.id)}
                                title={call.completed ? 'Mark as pending' : 'Mark as completed'}
                              >
                                {call.completed ? '↩️' : '✅'}
                              </button>
                              <button
                                className="wakeup-delete-btn"
                                onClick={() => deleteWakeUpCall(call.id)}
                                title="Delete wake-up call"
                              >
                                🗑️
                              </button>
                            </div>
                          </td>
                        </tr>
                      ))}
                  </tbody>
                </table>

                {wakeUpCalls.length === 0 && (
                  <div className="wakeup-fullscreen-empty">
                    <div className="wakeup-empty-icon">☎️</div>
                    <h3>No Wake-Up Calls</h3>
                    <p>Create your first wake-up call to get started.</p>
                    <button
                      className="wakeup-add-btn"
                      onClick={() => {
                        setShowWakeUpFullscreen(false);
                        setShowWakeUpModal(true);
                      }}
                    >
                      + Add Wake-Up Call
                    </button>
                  </div>
                )}
              </div>

              <div className="wakeup-fullscreen-footer">
                <div className="wakeup-bulk-actions">
                  {wakeUpCalls.length > 0 && (
                    <>
                      <button
                        className="wakeup-bulk-btn"
                        onClick={completeAllPendingWakeUpCalls}
                      >
                        ✅ Complete All Pending
                      </button>
                      <button
                        className="wakeup-bulk-btn wakeup-bulk-clear"
                        onClick={clearOldWakeUpCalls}
                      >
                        🧹 Clear Old Calls
                      </button>
                    </>
                  )}
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Handover Fullscreen Modal */}
      {showHandoverFullscreen && (
        <div className="handover-fullscreen-overlay">
          <div className="handover-fullscreen-container" role="dialog" aria-modal="true" aria-label="All handover notes">
            <div className="handover-fullscreen-header">
              <h2>📝 All Handover Notes</h2>
              <div className="handover-fullscreen-actions">
                <button
                  className="handover-add-btn"
                  onClick={() => {
                    setShowHandoverFullscreen(false);
                    setShowHandoverModal(true);
                  }}
                >
                  + Add New
                </button>
                <button
                  className="handover-fullscreen-close"
                  onClick={() => setShowHandoverFullscreen(false)}
                >
                  ✕
                </button>
              </div>
            </div>

            <div className="handover-fullscreen-content">
              <div className="handover-fullscreen-stats">
                <div className="handover-fullscreen-stat">
                  <span className="stat-number">{Object.keys(savedHandovers).length}</span>
                  <span className="stat-label">Total Days</span>
                </div>
                <div className="handover-fullscreen-stat">
                  <span className="stat-number">
                    {Object.values(savedHandovers).reduce((total, notes) => total + notes.split(' ').length, 0)}
                  </span>
                  <span className="stat-label">Total Words</span>
                </div>
                <div className="handover-fullscreen-stat">
                  <span className="stat-number">
                    {Object.keys(savedHandovers).filter(date => 
                      new Date(date).toDateString() === new Date().toDateString()
                    ).length > 0 ? '✅' : '❌'}
                  </span>
                  <span className="stat-label">Today's Notes</span>
                </div>
              </div>

              <div className="handover-fullscreen-table-container is-mobile-cards">
                {Object.keys(savedHandovers).length === 0 ? (
                  <div className="handover-fullscreen-empty">
                    <div className="handover-empty-icon">📝</div>
                    <h3>No Handover Notes Yet</h3>
                    <p>Click "Add New" to create your first handover note.</p>
                    <button
                      className="handover-add-btn"
                      onClick={() => {
                        setShowHandoverFullscreen(false);
                        setShowHandoverModal(true);
                      }}
                    >
                      + Add First Note
                    </button>
                  </div>
                ) : (
                  <table className="handover-fullscreen-table">
                    <thead>
                      <tr>
                        <th>Date</th>
                        <th>Day</th>
                        <th>Preview</th>
                        <th>Actions</th>
                      </tr>
                    </thead>
                    <tbody>
                      {Object.entries(savedHandovers)
                        .sort(([dateA], [dateB]) => new Date(dateB) - new Date(dateA))
                        .map(([date, notes]) => {
                          const dateObj = new Date(date);
                          const isToday = dateObj.toDateString() === new Date().toDateString();
                          const dayName = dateObj.toLocaleDateString('en-US', { weekday: 'long' });
                          
                          return (
                            <tr key={date} className={isToday ? 'handover-row-today' : ''}>
                              <td className="handover-date-cell">
                                <span className="handover-date-display">
                                  {dateObj.toLocaleDateString('en-US', { 
                                    month: 'short', 
                                    day: 'numeric',
                                    year: 'numeric'
                                  })}
                                </span>
                                {isToday && <span className="handover-today-badge">Today</span>}
                              </td>
                              <td className="handover-day-cell">
                                <span className="handover-day-name">{dayName}</span>
                              </td>
                              <td className="handover-notes-cell">
                                <div className="handover-notes-preview">
                                  {notes.length > 100 ? `${notes.substring(0, 100)}...` : notes}
                                </div>
                              </td>
                              <td className="handover-actions-cell">
                                <div className="handover-action-buttons">
                                  <button
                                    className="handover-edit-btn"
                                    onClick={() => {
                                      setHandoverDate(date);
                                      setShowHandoverFullscreen(false);
                                      setShowHandoverModal(true);
                                    }}
                                    title="Edit"
                                  >
                                    ✏️
                                  </button>
                                  <button
                                    className="handover-delete-small-btn"
                                    onClick={() => deleteHandoverNotes(date)}
                                    title="Delete"
                                  >
                                    🗑️
                                  </button>
                                </div>
                              </td>
                            </tr>
                          );
                        })}
                    </tbody>
                  </table>
                )}
              </div>
            </div>

            <div className="handover-fullscreen-footer">
              <div className="handover-bulk-actions">
                {Object.keys(savedHandovers).length > 0 && (
                  <>
                    <button
                      className="handover-export-btn"
                      onClick={() => {
                        const handoverText = Object.entries(savedHandovers)
                          .sort(([dateA], [dateB]) => new Date(dateB) - new Date(dateA))
                          .map(([date, notes]) => {
                            const dateObj = new Date(date);
                            const formattedDate = dateObj.toLocaleDateString('en-US', { 
                              weekday: 'long',
                              year: 'numeric',
                              month: 'long',
                              day: 'numeric'
                            });
                            return `${formattedDate}\n${'='.repeat(formattedDate.length)}\n${notes}\n\n`;
                          }).join('');
                        
                        const blob = new Blob([handoverText], { type: 'text/plain' });
                        const url = URL.createObjectURL(blob);
                        const a = document.createElement('a');
                        a.href = url;
                        a.download = `handover-notes-${new Date().toISOString().split('T')[0]}.txt`;
                        document.body.appendChild(a);
                        a.click();
                        document.body.removeChild(a);
                        URL.revokeObjectURL(url);
                      }}
                    >
                      📄 Export All
                    </button>
                    <button
                      className="handover-bulk-delete-btn"
                      onClick={deleteAllHandoverNotes}
                    >
                      🗑️ Clear All
                    </button>
                  </>
                )}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Breakfast Time Modal */}
      {showBreakfastModal && (
        <div className="info-modal-overlay" onClick={() => setShowBreakfastModal(false)}>
          <div className="breakfast-modal-box" onClick={(e) => e.stopPropagation()}>
            <h3>Edit Breakfast Times</h3>
            <div className="breakfast-modal-content">
              <div className="breakfast-modal-inputs">
                <div className="breakfast-input-group">
                  <label>Start Time:</label>
                  <input
                    type="time"
                    value={breakfastTimes.start}
                    onChange={(e) => setBreakfastTimes({...breakfastTimes, start: e.target.value})}
                    className="breakfast-modal-input"
                  />
                </div>
                <div className="breakfast-input-group">
                  <label>End Time:</label>
                  <input
                    type="time"
                    value={breakfastTimes.end}
                    onChange={(e) => setBreakfastTimes({...breakfastTimes, end: e.target.value})}
                    className="breakfast-modal-input"
                  />
                </div>
              </div>
              <div className="breakfast-modal-buttons">
                <button 
                  className="breakfast-modal-save-btn"
                  onClick={saveBreakfastTimes}
                >
                  Save Times
                </button>
                <button 
                  className="breakfast-modal-cancel-btn"
                  onClick={cancelBreakfastEdit}
                >
                  Cancel
                </button>
              </div>
            </div>
            <button 
              className="info-modal-close"
              onClick={() => setShowBreakfastModal(false)}
            >
              ×
            </button>
          </div>
        </div>
      )}

      {/* Shift complete */}
      {showCelebrationModal && (
        <div className="celebration-modal-overlay" onClick={() => setShowCelebrationModal(false)}>
          <div className="celebration-modal-box" role="dialog" aria-modal="true" aria-label="Shift completed" onClick={(e) => e.stopPropagation()}>
            <div className="celebration-ring" aria-hidden="true">
              <svg viewBox="0 0 52 52">
                <circle className="celebration-ring-circle" cx="26" cy="26" r="24" fill="none" />
                <path className="celebration-ring-check" fill="none" d="M14 27l8 8 16-17" />
              </svg>
            </div>
            <h2 className="celebration-title">Shift complete</h2>
            <p className="celebration-main-text">
              All {tasks.length} tasks done. Nice work, {initials}.
            </p>
            <p className="celebration-quote">
              {shift === 'Night' && 'The night team keeps the hotel running smoothly while the world sleeps.'}
              {shift === 'Morning' && 'Every great day starts with a dedicated morning team.'}
              {shift === 'Evening' && 'The evening team ensures every guest feels welcomed and cared for.'}
            </p>
            <button className="celebration-continue-btn" onClick={() => setShowCelebrationModal(false)}>
              Done
            </button>
            <button className="info-modal-close" onClick={() => setShowCelebrationModal(false)} aria-label="Close">×</button>
          </div>
        </div>
      )}

      {/* First-run welcome */}
      {showWelcomeModal && (
        <div className="info-modal-overlay" onClick={() => setShowWelcomeModal(false)}>
          <div className="welcome-modal-box" role="dialog" aria-modal="true" aria-label="Welcome" onClick={(e) => e.stopPropagation()}>
            <div className="welcome-modal-icon" aria-hidden="true">
              <span className="material-symbols-outlined">waving_hand</span>
            </div>
            <h3 className="welcome-modal-title">Welcome, {initials}</h3>
            <div className="welcome-modal-content">
              <p>Everything you check off syncs live to the rest of the team — no refresh needed.</p>
              <p>Use <strong>Start Task</strong> to show colleagues what you're working on, and add notes to leave context for the next shift.</p>
              <p className="welcome-modal-footnote">Spotted a bug or have an idea? Contact Ayush.</p>
            </div>
            <button className="welcome-modal-cta" onClick={() => setShowWelcomeModal(false)}>
              Start my shift
            </button>
            <button className="info-modal-close" onClick={() => setShowWelcomeModal(false)} aria-label="Close">×</button>
          </div>
        </div>
      )}
      <div className="frotask-fab-stack">
        <FloatingMapButton />
        <FloatingHskWidget currentUser={currentUser} userProfile={userProfile} />
      </div>

      {/* Admin Panel (admin only) */}
      {showAdmin && isAdmin && <AdminPanel onClose={() => setShowAdmin(false)} />}
    </div>
  );
}

export default App;