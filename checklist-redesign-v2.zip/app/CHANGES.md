# v2.0.0 — Design system unification & redesign

## Design system
- **One token layer** (`src/styles/tokens.css`) now drives the entire app. The two legacy
  systems (`--ios-*` and `--ft-*`) are remapped onto it, so shell, checklist, modals,
  login, HSK portal and admin share one palette, radius scale (6/10/14/20), 8px spacing
  grid, layered shadows and Inter typography (tabular numerals for times/counts).
- **Unified dark mode**: previously pure-black (`#000`) checklist surfaces sat next to
  `#121212` shell surfaces. Both now resolve to a single `#101014` night palette.
- Single accent color ("reception blue") replaces stock iOS blue; light/dark variants
  tuned for contrast.
- New polish layer (`src/styles/ui-polish.css`), loaded last: initials gate, loading
  skeletons, empty state, sync banner, restyled welcome + shift-complete modals.

## UX
- Task list shows **loading skeletons** while Firebase syncs and a proper **empty state**
  when a shift has no tasks (previously: silent void).
- **Escape closes any open modal/panel** (topmost first); modals carry
  `role="dialog"` / `aria-modal` semantics.
- Shift-complete moment redesigned: animated check-ring draw, calm copy — replaces the
  purple-gradient emoji burst. Shift quotes kept.
- Welcome modal copy rewritten (removed stale "test week" messaging).
- Initials gate redesigned with clear purpose copy ("who did what").
- Sync-error state is now a proper bottom toast instead of an inline-styled fixed box.
- Sidebar active item uses an accent-tinted pill; primary CTA has real hover/active
  states instead of `opacity: 0.8`.
- Theme toggle uses Material Symbols instead of emoji.

## Accessibility
- Removed `user-scalable=no` (WCAG 1.4.4 — pinch zoom now works).
- Global `:focus-visible` ring; `prefers-reduced-motion` respected app-wide.
- `color-scheme` declared per theme (native form controls match).

## Performance & code health
- **Removed 18 dead files** (~170KB source): `App_backup.jsx`, `App_test.jsx`, unused
  `components/index.js` barrel and everything only it referenced (LoginForm,
  InitialsForm, ShiftSelector, Sidebar, ChecklistTable, ProgressBar, SimpleMapModal),
  MapModal, SimpleMapTest(+css), HskChecklistPanel, HskRightPanel, useBackupScheduler,
  firebase/export.js, users.js.
- **Dropped `leaflet` + `react-leaflet`** (only the dead MapModal used them) — removes an
  entire vendor chunk from the bundle; CSP tightened accordingly (unpkg + OSM tiles
  removed). Run `npm install` to prune `node_modules` / lockfile.
- Deleted `public/index.html` (Firebase Hosting boilerplate that Vite copied into
  every production build).
- Removed a dead scroll handler + IntersectionObserver targeting `.left-sidebar
  .header-card` (element no longer exists) — ran on every scroll for nothing.
- Removed dead `{false && …}` JSX; deduplicated the handover-notes fetch on mount.
- `theme-color` meta now matches the actual palette in both themes.

## Known follow-ups (recommended)
- Replace remaining `window.confirm` / `alert` with an in-app confirm dialog + toast
  system (kept native for now — reliable, but not on-brand).
- Split `ChecklistApp` (~1,900 lines) into feature components (WakeUpCalls, Handover,
  TaskList) with colocated state.
- Lift FloatingMapButton / FloatingHskWidget modal state up so the mobile bottom nav
  stops triggering them via `document.querySelector(...).click()`.
- Add focus trapping to dialogs (Escape + semantics are in; trap is the last mile).
- `App.css` (~6,000 lines) still contains duplicate legacy blocks (e.g. three
  `.welcome-modal-box` definitions) that are now overridden — safe to prune gradually.
